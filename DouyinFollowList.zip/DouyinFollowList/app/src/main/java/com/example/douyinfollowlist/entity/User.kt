package com.example.douyinfollowlist.entity

data class User(
    val id: Long = 0, // 唯一标识（自增）
    val avatarResId: Int, // 本地头像资源ID
    val nickname: String, // 原始昵称
    var remark: String? = null, // 备注（可选）
    var isSpecialFocus: Boolean = false, // 是否特别关注（SQLite中存为1/0）
    val followTime: Long, // 关注时间戳（毫秒，用于排序）
    var isFollowed: Boolean = false // 添加这一行
)