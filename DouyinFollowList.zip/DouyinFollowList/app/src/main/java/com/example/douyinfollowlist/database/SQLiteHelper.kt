package com.example.douyinfollowlist.database

// database/SQLiteHelper.kt
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.douyinfollowlist.entity.User

// 数据库常量
object DBConstants {
    const val DB_NAME = "douyin_follow_db" // 数据库名
    const val DB_VERSION = 2 // 版本号
    const val TABLE_USER = "user" // 表名

    // 表字段
    const val COLUMN_ID = "_id" // 自增主键
    const val COLUMN_AVATAR = "avatarResId"
    const val COLUMN_NICKNAME = "nickname"
    const val COLUMN_REMARK = "remark"
    const val COLUMN_SPECIAL_FOCUS = "isSpecialFocus" // 1=是，0=否
    const val COLUMN_FOLLOW_TIME = "followTime"
    const val COLUMN_IS_FOLLOWED = "isFollowed" // 新增: 关注状态字段
}

class SQLiteHelper(context: Context) : SQLiteOpenHelper(
    context,
    DBConstants.DB_NAME,
    null,
    DBConstants.DB_VERSION
) {

    // 创建表（首次创建数据库时调用）
    override fun onCreate(db: SQLiteDatabase) {
        val createTableSql = """
            CREATE TABLE ${DBConstants.TABLE_USER} (
                ${DBConstants.COLUMN_ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${DBConstants.COLUMN_AVATAR} INTEGER NOT NULL,
                ${DBConstants.COLUMN_NICKNAME} TEXT NOT NULL,
                ${DBConstants.COLUMN_REMARK} TEXT,
                ${DBConstants.COLUMN_SPECIAL_FOCUS} INTEGER DEFAULT 0,
                ${DBConstants.COLUMN_FOLLOW_TIME} INTEGER NOT NULL,
                ${DBConstants.COLUMN_IS_FOLLOWED} INTEGER DEFAULT 1  -- 默认为已关注
            
            )
        """.trimIndent()
        db.execSQL(createTableSql)
    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < newVersion) {
            // 版本1升级到版本2: 添加关注状态字段
            if (oldVersion < 2) {
                db.execSQL("ALTER TABLE ${DBConstants.TABLE_USER} ADD COLUMN ${DBConstants.COLUMN_IS_FOLLOWED} INTEGER DEFAULT 1")
            }
        }
    }
}