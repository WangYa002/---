package com.example.douyinfollowlist

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity


// MainActivity.kt
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.recyclerview.widget.RecyclerView

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import android.app.AlertDialog
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.douyinfollowlist.adapter.FollowAdapter
import com.example.douyinfollowlist.dao.FollowDao
import com.example.douyinfollowlist.database.SQLiteHelper
import com.example.douyinfollowlist.entity.User
import com.example.douyinfollowlist.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import androidx.lifecycle.lifecycleScope
import java.util.*
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.view.Gravity

class MainActivity : AppCompatActivity(), FollowAdapter.OnFollowActionListener {

    private lateinit var followAdapter: FollowAdapter
    private lateinit var dbHelper: SQLiteHelper
    private lateinit var followDao: FollowDao
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 使用 binding 引用 toolbar 初始化标题栏
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        // 初始化SQLite
        dbHelper = SQLiteHelper(this)
        followDao = FollowDao(dbHelper)

        // 初始化 ViewPager2 和 TabLayout
        viewPager = binding.viewPager
        tabLayout = binding.tabLayout

        // 设置适配器
        val adapter = ViewPagerAdapter(this)
        viewPager.adapter = adapter

        // 连接 TabLayout 和 ViewPager2
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "关注"
                1 -> "互相关注"
                2 -> "粉丝"
                3 -> "朋友"
                else -> ""
            }
        }.attach()

        // 初始化测试数据（首次启动时插入）
        initTestData()
    }
    private fun observeFollowList() {
        followDao.queryAllUsers().observe(this, Observer { userList ->
            // 从 FollowListFragment 获取 followAdapter
            val fragment = supportFragmentManager.findFragmentByTag("FollowListFragment") as? FollowListFragment
            fragment?.followAdapter?.updateData(userList)
        })
    }

    override fun onSetFollowStatus(user: User, isFollowed: Boolean) {
        // 更新数据库中的用户状态
        lifecycleScope.launch(Dispatchers.IO) {
            val updatedUser = user.copy(isFollowed = isFollowed)
            followDao.updateUser(updatedUser)

            // 更新UI显示
            runOnUiThread {
                val fragment = supportFragmentManager.findFragmentByTag("FollowListFragment") as? FollowListFragment
                fragment?.followAdapter?.updateButtonStatus(user.id, isFollowed)

                Toast.makeText(
                    this@MainActivity,
                    if (isFollowed) "已关注" else "已取消关注",
                    Toast.LENGTH_SHORT
                ).show()
            }
            refreshFollowList()
        }
    }



    // ViewPager2 适配器
    private inner class ViewPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
        override fun getItemCount(): Int = 4

        override fun createFragment(position: Int): Fragment {
            return when (position) {
                0 -> FollowListFragment.newInstance()
                1 -> MutualFollowFragment()
                2 -> FansFragment()
                3 -> FriendsFragment()
                else -> FollowListFragment.newInstance()
            }
        }
    }

    // 初始化测试数据（10条模拟关注用户）
    private fun initTestData() {
        lifecycleScope.launch(Dispatchers.IO) {
            val userCount = followDao.getUserCount()
            if (userCount == 0) {
                val testUsers = listOf(
                    User(avatarResId = R.drawable.jayzhou, nickname = "周杰伦", remark = "中国好声音", followTime = System.currentTimeMillis() - 1000000, isFollowed = false),
                    User(avatarResId = R.drawable.shaohan, nickname = "王心凌", remark = "爱你", isSpecialFocus = true, followTime = System.currentTimeMillis() - 2000000, isFollowed = true),
                    User(avatarResId = R.drawable.jj ,nickname = "林俊杰", followTime = System.currentTimeMillis() - 3000000, isFollowed = true),
                    User(avatarResId = R.drawable.liangying, nickname = "张韶涵", isSpecialFocus = true, followTime = System.currentTimeMillis() - 4000000, isFollowed = true),
                    User(avatarResId = R.drawable.shaohan, nickname = "张靓颖", remark = "开黑队友", followTime = System.currentTimeMillis() - 5000000, isFollowed = true),
                    User(avatarResId = R.drawable.wuyuetian, nickname = "五月天", followTime = System.currentTimeMillis() - 6000000, isFollowed = true),
                    User(avatarResId = R.drawable.qian, nickname = "薛之签", followTime = System.currentTimeMillis() - 7000000, isFollowed = false),
                    User(avatarResId = R.drawable.bin, nickname = "BLG.bin", remark = "快乐源泉", followTime = System.currentTimeMillis() - 8000000, isFollowed = false),
                    User(avatarResId = R.drawable.viper, nickname = "BLG.Viper", followTime = System.currentTimeMillis() - 9000000, isFollowed = false),
                    User(avatarResId = R.drawable.dehua, nickname = "刘德华", followTime = System.currentTimeMillis() - 10000000, isFollowed = true)
                )
                followDao.insertUsers(testUsers)
            }
        }
    }

    // 1. 设为/取消特别关注
    override fun onSetSpecialFocus(user: User, isSpecial: Boolean) {
        lifecycleScope.launch(Dispatchers.IO) {
            // 当设置特别关注时，同时确保用户处于关注状态
            val updatedUser = if (isSpecial) {
                user.copy(isSpecialFocus = true, isFollowed = true)
            } else {
                user.copy(isSpecialFocus = false)
            }
            followDao.updateUser(updatedUser)
            runOnUiThread {
                Toast.makeText(
                    this@MainActivity,
                    if (isSpecial) "已设为特别关注" else "已取消特别关注",
                    Toast.LENGTH_SHORT
                ).show()
                observeFollowList() // 重新查询更新UI
            }
        }
    }

    // 2. 设置备注
    override fun onSetRemark(user: User, remark: String) {
        // 弹出输入对话框
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_set_remark, null)
        val etRemark = view.findViewById<EditText>(R.id.et_remark)
        etRemark.setText(remark)

        AlertDialog.Builder(this)
            .setTitle("设置备注")
            .setView(view)
            .setPositiveButton("确定") { dialog, _ ->
                val newRemark = etRemark.text.toString().trim()
                lifecycleScope.launch(Dispatchers.IO) {
                    // 更新数据库
                    val updatedUser = user.copy(remark = if (newRemark.isNotEmpty()) newRemark else null)
                    followDao.updateUser(updatedUser)

                    runOnUiThread {
                        // 更新UI显示
                        val fragment = supportFragmentManager.findFragmentByTag("FollowListFragment") as? FollowListFragment
                        fragment?.followAdapter?.updateDataWithRemark(user.id, newRemark)

                        Toast.makeText(this@MainActivity, "备注已保存", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                    }
                }
            }
            .setNegativeButton("取消") { dialog, _ -> dialog.dismiss() }
            .show()
    }


    // 3. 取消关注
    override fun onUnfollow(user: User) {
        AlertDialog.Builder(this)
            .setTitle("取消关注")
            .setMessage("确定要取消关注 ${user.remark ?: user.nickname} 吗？")
            .setPositiveButton("确定") { dialog, _ ->
                // 更新数据库中的用户状态（与 onSetFollowStatus 相同的逻辑）
                lifecycleScope.launch(Dispatchers.IO) {
                    // 取消关注时同时取消特别关注
                    val updatedUser = user.copy(
                        isFollowed = false,
                        isSpecialFocus = false  // 同时取消特别关注
                    )
                    followDao.updateUser(updatedUser)

                    // 更新UI显示
                    runOnUiThread {
                        val fragment = supportFragmentManager.findFragmentByTag("FollowListFragment") as? FollowListFragment
                        fragment?.followAdapter?.updateButtonStatus(user.id, false)

                        Toast.makeText(this@MainActivity, "已取消关注", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                    }
                }
            }
            .setNegativeButton("取消") { dialog, _ -> dialog.dismiss() }
            .show()
    }


    // 关闭数据库连接
    override fun onDestroy() {
        super.onDestroy()
        dbHelper.close()
    }

    private fun refreshFollowList() {
        val fragment = supportFragmentManager.findFragmentByTag("FollowListFragment") as? FollowListFragment
        fragment?.followAdapter?.updateData(fragment.followDao.queryAllUsers().value ?: emptyList())
    }
}



// 在 MutualFollowFragment 之前添加这个类
class FollowListFragment : Fragment() {

    lateinit var followAdapter: FollowAdapter
    private lateinit var dbHelper: SQLiteHelper
    lateinit var followDao: FollowDao

    companion object {
        fun newInstance(): FollowListFragment {
            return FollowListFragment()
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // 使用新的 Fragment 布局
        val view = inflater.inflate(R.layout.fragment_follow_list, container, false)

        // 初始化SQLite
        dbHelper = SQLiteHelper(requireContext())
        followDao = FollowDao(dbHelper)

        // 初始化列表
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        val swipeRefresh = view.findViewById<SwipeRefreshLayout>(R.id.swipe_refresh)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        followAdapter = FollowAdapter(requireActivity(), emptyList(), requireActivity() as FollowAdapter.OnFollowActionListener)
        recyclerView.adapter = followAdapter

        // 观察用户列表数据变化（LiveData回调）
        observeFollowList()

        // 下拉刷新：重新查询数据
        swipeRefresh.setOnRefreshListener {
            observeFollowList() // 重新获取数据
            swipeRefresh.isRefreshing = false // 关闭刷新动画
        }

        return view
    }

    // 观察关注列表数据变化（LiveData回调更新UI）
    private fun observeFollowList() {
        followDao.queryAllUsers().observe(viewLifecycleOwner) { userList ->
            followAdapter.updateData(userList)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::dbHelper.isInitialized) {
            dbHelper.close()
        }
    }
}




class MutualFollowFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val textView = TextView(context).apply {
            text = "互相关注页面\n暂无内容"
            gravity = Gravity.CENTER
            textSize = 24f
        }
        return textView
    }
}

class FansFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val textView = TextView(context).apply {
            text = "粉丝页面\n暂无内容"
            gravity = Gravity.CENTER
            textSize = 24f
        }
        return textView
    }
}

class FriendsFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val textView = TextView(context).apply {
            text = "朋友页面\n暂无内容"
            gravity = Gravity.CENTER
            textSize = 24f
        }
        return textView
    }
}


