package com.example.douyinfollowlist.adapter

// adapter/FollowAdapter.kt
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.douyinfollowlist.R
import com.example.douyinfollowlist.entity.User
import android.widget.ImageView
import de.hdodenhof.circleimageview.CircleImageView
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import com.example.douyinfollowlist.FollowListFragment
import com.google.android.material.bottomsheet.BottomSheetDialog




// 在 adapter/FollowAdapter.kt 中修改
class FollowAdapter(
    private val context: Context,
    private var userList: List<User>,
    private val listener: OnFollowActionListener
) : RecyclerView.Adapter<FollowAdapter.ViewHolder>() {

    interface OnFollowActionListener {
        fun onSetSpecialFocus(user: User, isSpecial: Boolean)
        fun onSetRemark(user: User, remark: String)
        fun onUnfollow(user: User)
        fun onSetFollowStatus(user: User, isFollowed: Boolean) // 添加这一行
    }

    // 添加recyclerView引用
    private var recyclerView: RecyclerView? = null

    // 在onAttachedToRecyclerView中保存recyclerView引用
    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        this.recyclerView = recyclerView
    }

    // 在onDetachedFromRecyclerView中清理引用
    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        this.recyclerView = null
        super.onDetachedFromRecyclerView(recyclerView)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivAvatar: CircleImageView = itemView.findViewById(R.id.iv_avatar)
        val tvName: TextView = itemView.findViewById(R.id.tv_name)
        val tvRemark: TextView = itemView.findViewById(R.id.tv_remark)
        val tvSpecialFocus: TextView = itemView.findViewById(R.id.tv_special_focus)
        val btnFollowed: Button = itemView.findViewById(R.id.btn_followed)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_follow, parent, false)
        return ViewHolder(view)
    }

    fun updateDataWithRemark(userId: Long, remark: String?) {
        val index = userList.indexOfFirst { it.id == userId }
        if (index != -1) {
            val updatedList = userList.toMutableList()
            updatedList[index] = updatedList[index].copy(remark = if (remark?.isNotEmpty() == true) remark else null)
            userList = updatedList
            notifyItemChanged(index)
        }
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = userList[position]

        // 设置头像
        Glide.with(context).load(user.avatarResId).into(holder.ivAvatar)

        // 设置昵称
        holder.tvName.text = user.nickname

        // 设置备注
        holder.tvRemark.text = user.remark ?: ""

        // 设置特别关注状态
        holder.tvSpecialFocus.visibility = if (user.isSpecialFocus) View.VISIBLE else View.GONE

        // 设置关注按钮状态
        updateFollowButtonAppearance(holder.btnFollowed, user.isFollowed)

        // 设置点击事件
        holder.btnFollowed.setOnClickListener {
            listener.onSetFollowStatus(user, !user.isFollowed)
        }


        holder.itemView.findViewById<View>(R.id.btn_more).setOnClickListener {
            showBottomSheetDialog(user, it)
        }
    }

    private fun updateFollowButtonAppearance(button: Button, isFollowed: Boolean) {
        if (isFollowed) {
            button.text = "已关注"
            button.setBackgroundResource(R.drawable.bg_followed_btn_selected)
        } else {
            button.text = "关注"
            button.setBackgroundResource(R.drawable.bg_followed_btn_normal)
        }
    }



    private fun showBottomSheetDialog(user: User, anchorView: View) {
        val bottomSheetDialog = BottomSheetDialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_follow, null)

        // 设置标题
        val tvName = view.findViewById<TextView>(R.id.tv_name)
        tvName.text = user.nickname

        // 设置特别关注开关
        val switchSpecialFocus = view.findViewById<Switch>(R.id.switch_special_focus)
        switchSpecialFocus.isChecked = user.isSpecialFocus
        switchSpecialFocus.setOnCheckedChangeListener { _, isChecked ->
            listener.onSetSpecialFocus(user, isChecked)
        }

        // 设置备注编辑
        val etRemark = view.findViewById<EditText>(R.id.et_remark)
        etRemark.setText(user.remark ?: "")
        etRemark.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.isNotEmpty() == true) {
                    listener.onSetRemark(user, s.toString())
                }
            }
        })

        // 设置取消关注按钮
        val btnUnfollow = view.findViewById<Button>(R.id.btn_unfollow)
        btnUnfollow.setOnClickListener {
            listener.onUnfollow(user)
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.setContentView(view)
        bottomSheetDialog.show()
    }


    fun updateData(newList: List<User>) {
        userList = newList
        notifyDataSetChanged()
    }

    fun updateUserStatus(userId: Long, isFollowed: Boolean) {
        val index = userList.indexOfFirst { it.id == userId }
        if (index != -1) {
            val updatedList = userList.toMutableList()
            updatedList[index] = updatedList[index].copy(isFollowed = isFollowed)
            userList = updatedList
            notifyItemChanged(index)
        }
    }

    fun updateButtonStatus(userId: Long, isFollowed: Boolean) {
        val index = userList.indexOfFirst { it.id == userId }
        if (index != -1) {
            // 更新数据
            val updatedList = userList.toMutableList()
            updatedList[index] = updatedList[index].copy(isFollowed = isFollowed)
            userList = updatedList

            // 直接更新按钮外观
            updateButtonAtPosition(index, isFollowed)

            // 如果上述方法不工作，则使用原来的notify方式作为备选
            // notifyItemChanged(index)
        }
    }

    private fun updateButtonAtPosition(position: Int, isFollowed: Boolean) {
        try {
            val viewHolder = recyclerView?.findViewHolderForAdapterPosition(position) as? ViewHolder
            viewHolder?.let {
                updateFollowButtonAppearance(it.btnFollowed, isFollowed)
            }
        } catch (e: Exception) {
            // 如果直接更新失败，回退到notify方式
            notifyItemChanged(position)
        }
    }




    override fun getItemCount() = userList.size
}
