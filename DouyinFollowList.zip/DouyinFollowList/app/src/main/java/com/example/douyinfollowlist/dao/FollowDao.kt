package com.example.douyinfollowlist.dao

// dao/FollowDao.kt
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.douyinfollowlist.database.DBConstants
import com.example.douyinfollowlist.database.SQLiteHelper
import com.example.douyinfollowlist.entity.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FollowDao(private val dbHelper: SQLiteHelper) {

        // 1. 插入单个用户（添加 isFollowed 字段）
        suspend fun insertUser(user: User) {
            withContext(Dispatchers.IO) {
                val db = dbHelper.writableDatabase
                val values = ContentValues().apply {
                    put(DBConstants.COLUMN_AVATAR, user.avatarResId)
                    put(DBConstants.COLUMN_NICKNAME, user.nickname)
                    put(DBConstants.COLUMN_REMARK, user.remark)
                    put(DBConstants.COLUMN_SPECIAL_FOCUS, if (user.isSpecialFocus) 1 else 0)
                    put(DBConstants.COLUMN_FOLLOW_TIME, user.followTime)
                    put(DBConstants.COLUMN_IS_FOLLOWED, if (user.isFollowed) 1 else 0) // 添加这行
                }
                db.insert(DBConstants.TABLE_USER, null, values)
                db.close()
            }
        }

        // 2. 批量插入用户（添加 isFollowed 字段）
        suspend fun insertUsers(users: List<User>) {
            withContext(Dispatchers.IO) {
                val db = dbHelper.writableDatabase
                db.beginTransaction() // 开启事务，提升批量插入效率
                try {
                    users.forEach { user ->
                        val values = ContentValues().apply {
                            put(DBConstants.COLUMN_AVATAR, user.avatarResId)
                            put(DBConstants.COLUMN_NICKNAME, user.nickname)
                            put(DBConstants.COLUMN_REMARK, user.remark)
                            put(DBConstants.COLUMN_SPECIAL_FOCUS, if (user.isSpecialFocus) 1 else 0)
                            put(DBConstants.COLUMN_FOLLOW_TIME, user.followTime)
                            put(DBConstants.COLUMN_IS_FOLLOWED, if (user.isFollowed) 1 else 0) // 添加这行
                        }
                        db.insert(DBConstants.TABLE_USER, null, values)
                    }
                    db.setTransactionSuccessful() // 事务成功
                } finally {
                    db.endTransaction() // 结束事务
                    db.close()
                }
            }
        }

        // 4. 更新用户（备注/特别关注/关注状态）
        suspend fun updateUser(user: User) {
            withContext(Dispatchers.IO) {
                val db = dbHelper.writableDatabase
                val values = ContentValues().apply {
                    put(DBConstants.COLUMN_REMARK, user.remark)
                    put(DBConstants.COLUMN_SPECIAL_FOCUS, if (user.isSpecialFocus) 1 else 0)
                    put(DBConstants.COLUMN_IS_FOLLOWED, if (user.isFollowed) 1 else 0) // 添加这行
                }
                db.update(
                    DBConstants.TABLE_USER,
                    values,
                    "${DBConstants.COLUMN_ID} = ?",
                    arrayOf(user.id.toString())
                )
                db.close()
            }
        }

        // 5. 按关注时间倒序查询所有用户（核心排序），返回LiveData
        fun queryAllUsers(): LiveData<List<User>> {
            val liveData = MutableLiveData<List<User>>()
            GlobalScope.launch(Dispatchers.IO) {
                val db = dbHelper.readableDatabase
                val cursor: Cursor = db.query(
                    DBConstants.TABLE_USER,
                    null, // 查询所有字段
                    null,
                    null,
                    null,
                    null,
                    "${DBConstants.COLUMN_FOLLOW_TIME} DESC" // 按关注时间倒序
                )
                val userList = mutableListOf<User>()
                while (cursor.moveToNext()) {
                    val user = User(
                        id = cursor.getLong(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_ID)),
                        avatarResId = cursor.getInt(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_AVATAR)),
                        nickname = cursor.getString(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_NICKNAME)),
                        remark = cursor.getString(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_REMARK)),
                        isSpecialFocus = cursor.getInt(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_SPECIAL_FOCUS)) == 1,
                        followTime = cursor.getLong(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_FOLLOW_TIME)),
                        isFollowed = cursor.getInt(cursor.getColumnIndexOrThrow(DBConstants.COLUMN_IS_FOLLOWED)) == 1 // 修改这行
                    )
                    userList.add(user)
                }
                cursor.close()
                db.close()
                liveData.postValue(userList) // 子线程更新LiveData
            }
            return liveData
        }

    // 6. 查询用户总数（初始化测试数据用）
    suspend fun getUserCount(): Int {
        return withContext(Dispatchers.IO) {
            val db = dbHelper.readableDatabase
            val cursor: Cursor = db.query(
                DBConstants.TABLE_USER,
                arrayOf("COUNT(*)"), // 统计行数
                null,
                null,
                null,
                null,
                null
            )
            var count = 0
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0)
            }
            cursor.close()
            db.close()
            count
        }
    }
}